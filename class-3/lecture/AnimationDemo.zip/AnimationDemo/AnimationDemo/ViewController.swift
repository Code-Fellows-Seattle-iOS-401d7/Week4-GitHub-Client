//
//  ViewController.swift
//  AnimationDemo
//
//  Created by Adam Wallraff on 11/1/16.
//  Copyright © 2016 Adam Wallraff. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var button1: UIButton!
    @IBOutlet weak var button2: UIButton!
    @IBOutlet weak var button3: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
//        animateButton1()
        
        animateAllButtons()
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func animateButton1(){
        
        UIView.animate(withDuration: 5.0, animations: {
            self.button1.alpha = 0.5
        }, completion: { (finished) in
            
        })
    }
    
    func animateButton2(){
        UIView.animate(withDuration: 10.0, delay: 1.0, usingSpringWithDamping: 0.1, initialSpringVelocity: 0.75, options: .curveEaseInOut, animations: {
            
            self.button2.alpha = 0.5
            
        }, completion: { (finished) in
            
        })
    }
    
    
    func animateAllButtons(){
    
        UIView.animateKeyframes(withDuration: 10.0, delay: 0.0, options: .calculationModeLinear, animations: {
            
            UIView.addKeyframe(withRelativeStartTime: 0.0, relativeDuration: 0.25, animations: {
                self.button1.transform = CGAffineTransform(a: <#T##CGFloat#>, b: <#T##CGFloat#>, c: <#T##CGFloat#>, d: <#T##CGFloat#>, tx: <#T##CGFloat#>, ty: <#T##CGFloat#>)
                
                
            })
            
            UIView.addKeyframe(withRelativeStartTime: 0.25, relativeDuration: 0.5, animations: {
                self.button2.transform = CGAffineTransform(scaleX: 0.5, y: 0.5)
            })
            
            UIView.addKeyframe(withRelativeStartTime: 0.5, relativeDuration: 0.5, animations: {
                self.button3.alpha = 0.5
                self.button3.backgroundColor = UIColor.blue
            })
            
            
        }, completion: { (finished) in
            self.button2.transform = CGAffineTransform.identity

            
            print("Do some other functionality reliant on completed animation...")
        })
        
        print("Some other code running....")

    
    
    
    }
    

}

















